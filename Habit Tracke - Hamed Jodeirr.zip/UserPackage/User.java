package UserPackage;
import TaskPackage.Task;
import UserPackage.User;
import UtilityPackage.Utils;

import java.text.DecimalFormat;
import java.util.Scanner;


public class User {
    private String username;
    private String password;

    public String first_name;
    public String last_name;
    public String email;
    public int streak;

    private Task[] tasks = new Task[10];
    private int taskCounter = 0;

    public User(String username, String password, String first_name, String last_name, String email) {
        setUsername(username);
        setPassword(password);
        this.first_name = first_name;
        this.last_name = last_name;
        this.email = email;
    }

    public Task createTask(String taskName) {
        if (isTaskRepetitive(taskName) == false) {
            Task t1 = new Task(taskName, this);
            tasks[taskCounter] = t1;
            taskCounter++;
            return t1;
            
        }
        else {
            System.out.println("Task is already in your task list. Enter new task name: ");
            Scanner scan = new Scanner(System.in);
            String p = scan.next();
            scan.close();
            return createTask(p);
        }

    }



    private boolean isTaskRepetitive(String taskName) {
        for (int i = 0; i < taskCounter; i++) {
            if (taskName == tasks[i].name) {
                return true;
            }
        }
        return false;
    }

    public String getFullName() {
        String fullName = first_name + last_name;
        return fullName;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getUsername() {
        return username;
    }
    public void setPassword(String password) {
        if (Utils.isPasswordValid(password) == true) {
            this.password = password;
        }
        else {
            System.out.println("New password is INVALID. Password must include at least a letter and a digit: ");
            Scanner scan = new Scanner(System.in);
            String p = scan.next();
            scan.close();
            setPassword(p);
        }
    }
    public String getPassword() {
        return password;
    }

}