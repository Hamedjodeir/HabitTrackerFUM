package UtilityPackage;
import TaskPackage.Task;
import UserPackage.User;


public class Utils {
    public static boolean isPasswordValid(String password) {
        boolean answer1 = false;
        boolean answer2 = false;
        for (int i = 0; i < password.length(); i++) {
            if ((Character.isLetter(password.charAt(i))) == true) {
                answer1 = true;
            }
            else if ((Character.isDigit(password.charAt(i))) == true) {
                answer2 = true;
            }
        }
        if (answer1 == true && answer2 == true) {
            return true;
        }
        else {
            return false;
        }
    }
}
